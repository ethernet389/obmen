package com.ethernet389.testsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Animatable;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class AboutActivity extends AppCompatActivity {
    TextView about;
    ImageView gentelmen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        about = findViewById(R.id.about_text);
        gentelmen = findViewById(R.id.gentelmen);

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Версия: " + getResources().getString(R.string.version) + "\n");
        stringBuilder.append("Дата релиза: " + getResources().getString(R.string.release_date_version) + "\n");
        stringBuilder.append("\n");
        stringBuilder.append("Разработчик: " + getResources().getString(R.string.developer) + "\n");
        stringBuilder.append("Эл.почта: " + getResources().getString(R.string.email));
        about.setText(stringBuilder.toString());

        Animation anim = AnimationUtils.loadAnimation(this, R.anim.rotating);
        gentelmen.setAnimation(anim);
    }
}