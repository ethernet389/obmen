package com.ethernet389.testsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class StatisticActivity extends AppCompatActivity {
    boolean[] test_answers;

    TextView result;
    ImageView allTrueJPG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistic);
        test_answers = getIntent().getBooleanArrayExtra("test_answers");
        result = findViewById(R.id.result);

        StringBuilder buff = new StringBuilder();
        boolean allTrue = true;
        for (int i = 0; i != test_answers.length; ++i) {
            if (!test_answers[i]) allTrue = false;
            buff.append("Вопрос #" + (i + 1) + ": " + (test_answers[i] ? "Верно" : "Неверно") + "\n");
        }

        if (allTrue) {
            allTrueJPG = findViewById(R.id.allTrueJPG);
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.fade_in);
            allTrueJPG.setAnimation(anim);
            Toast.makeText(this, "Красава!", Toast.LENGTH_SHORT).show();
        }
        result.setText(buff.toString());
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()){
            case R.id.about:
                Intent intent = new Intent(StatisticActivity.this, AboutActivity.class);
                startActivity(intent);
                break;
            case R.id.exit:
                onDestroy();
                break;
            default:
        }
        return true;
    }
}