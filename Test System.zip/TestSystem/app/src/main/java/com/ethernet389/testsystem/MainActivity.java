package com.ethernet389.testsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int countQuest = 1;
    String[] tests;

    boolean[] test_answers;

    Resources resources;

    TextView theme;
    TextView quest;
    TextView numQuest;
    TextView numQuest1;
    RadioGroup varAnswers;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resources = getResources();
        theme = findViewById(R.id.theme);
        quest = findViewById(R.id.quest);
        numQuest = findViewById(R.id.numQuest);
        numQuest1 = findViewById(R.id.numQuest1);
        varAnswers = findViewById(R.id.varAnswers);
        tests = resources.getStringArray(R.array.test0);

        test_answers = new boolean[tests.length / 5];

        theme.setText(resources.getString(R.string.test0));
        numQuest.setText(("Вопрос #" + countQuest));
        quest.setText(tests[countQuest - 1]);
        numQuest1.setText((countQuest + "/" + tests.length / 5));

        for (int i = 0; i != varAnswers.getChildCount(); ++i){
            ((RadioButton)varAnswers.getChildAt(i)).setTextSize(1, 20);

            if(tests[i + 1].endsWith("+")) {
                ((RadioButton)varAnswers.getChildAt(i)).setText(tests[i + 1].substring(0, tests[i + 1].length() - 1));
                continue;
            }
            ((RadioButton)varAnswers.getChildAt(i)).setText(tests[i + 1]);
        }
    }

    public void onButton(View view) {
        for (int i = 0; i != varAnswers.getChildCount(); ++i){
            if (((RadioButton)varAnswers.getChildAt(i)).isChecked()){
                // TODO: 22.11.22 Add test-checker
                String answer = ((RadioButton)varAnswers.getChildAt(i)).getText().toString();
                for (int j = (countQuest - 1) * 5; j < (countQuest + 4) * 5; ++j){
                    if (tests[j].endsWith("+")) {test_answers[countQuest - 1] =
                            tests[j].substring(0, tests[j].length() - 1).equals(answer); break;}
                }
                break;
            }
        }


        //Смена ответа
        ++countQuest;

        if (countQuest <= tests.length / 5) {
            numQuest.setText(("Вопрос #" + countQuest));
            quest.setText(tests[(countQuest - 1) * 5]);
            numQuest1.setText((countQuest + "/" + tests.length / 5));

            for (int i = 0; i != varAnswers.getChildCount(); ++i) {
                if (tests[i + 1 + (countQuest - 1) * 5].endsWith("+")) {
                    ((RadioButton) varAnswers.getChildAt(i)).setText(tests[i + 1 + (countQuest - 1) * 5].substring(0, tests[i + 1 + (countQuest - 1) * 5].length() - 1));
                    continue;
                }
                ((RadioButton) varAnswers.getChildAt(i)).setText(tests[i + 1 + (countQuest - 1) * 5]);
            }
            return;
        }

        Intent intent = new Intent(MainActivity.this, StatisticActivity.class);
        intent.putExtra("test_answers", test_answers);
        startActivity(intent);

        MainActivity.this.finish();
        // TODO: 22.11.22 Статистика 
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()){
            case R.id.about:
                Intent intent = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(intent);
                break;
            case R.id.exit:
                finish();
                break;
            default:
        }
        return true;
    }
}