package com.ethernet389.hw1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<StringPair> logPassList = new ArrayList<>();

    EditText login;
    EditText password;
    TextView status;
    ImageView gentelmen;
    Button button;

    String inputLogin;
    String inputPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.enterButton);
        status = findViewById(R.id.statusView);
        password = findViewById(R.id.passwordEditText);
        login = findViewById(R.id.loginEditText);
        gentelmen = findViewById(R.id.gentelmen);

        XmlPullParser xpp = getResources().getXml(R.xml.logins_passwords);
        LoginPasswordXMLparser.GetLoginsPasswords(xpp, logPassList);
    }

    public void onButtonClick(View view) {
        inputLogin = login.getText().toString();
        inputPassword = password.getText().toString();

        boolean ThisContains = false;
        for (StringPair i : logPassList) if (i.first.equals(inputLogin) && i.second.equals(inputPassword)) {ThisContains = true; break;}

        if (ThisContains){
            status.setBackgroundColor(Color.rgb(102, 255, 102));
            status.setText("Logged");
            gentelmen.setImageDrawable(getResources().getDrawable(R.drawable.gentelmen));
            Toast.makeText(this, "Hello, " + inputLogin +"!", Toast.LENGTH_SHORT).show();
            return;
        }

        status.setBackgroundColor(Color.rgb(255, 102, 102));
        status.setText("Incorrect login or password");
        Toast.makeText(this, "Try again!", Toast.LENGTH_SHORT).show();

        login.setText("Login");
        password.setText("Password");
        gentelmen.setImageDrawable(null);
    }
}