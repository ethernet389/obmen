package com.ethernet389.hw1;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.util.ArrayList;

public class LoginPasswordXMLparser {
    static public void GetLoginsPasswords(XmlPullParser xpp, ArrayList<StringPair> container) {
        try{
            int eventType = xpp.getEventType();
            boolean inEntry = false;
            StringPair logPass = new StringPair();

            while(eventType != XmlPullParser.END_DOCUMENT){
                String tagName = xpp.getName();

                switch(eventType){
                    case XmlPullParser.START_TAG:
                        if ("login".equalsIgnoreCase(tagName))inEntry = true;
                        logPass = new StringPair();
                        break;
                    case XmlPullParser.TEXT:
                        String[] buff = xpp.getText().split(" ");
                        logPass.first = buff[0];
                        logPass.second = buff[1];
                        break;
                    case XmlPullParser.END_TAG:
                        if (inEntry) {
                            if ("login".equalsIgnoreCase(tagName)) {
                                container.add(logPass);
                                inEntry = false;
                            }
                        }
                        break;
                    default:
                }
                eventType = xpp.next();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}
