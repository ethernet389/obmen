package com.ethernet389.hw1;

public class StringPair{
    public StringPair(){
        first = "";
        second = "";
    }

    public StringPair(java.lang.String first, java.lang.String second){
        this.first = first;
        this.second = second;
    }

    public java.lang.String first;
    public java.lang.String second;
}
